# Software Design Description: Integration Drop Readiness Gate

**Status:** Proposed design for the training exercise  
**Source:** [Software Integrator Copilot Training Requirements](Software_Integrator_Copilot_Training_Requirements.md)  
**Scope note:** This document describes the integration-readiness-gate exercise only. It does not select or define the architecture of the production vehicle telemetry system.

## 1. Purpose

The Integration Drop Readiness Gate compares a candidate software-drop manifest with an approved, version-controlled policy. It returns a deterministic JSON report with status `READY` or `BLOCKED` and the blocking issues found. Identical validation logic is used by a local command and an AWS Lambda function.

`READY` means only that the manifest satisfies the configured readiness rules. It does not validate binaries, prove that checksums match artifacts, constitute product QA, or approve a release.

## 2. Scope and Constraints

### In scope

- Parse and validate UTF-8 JSON manifests and policy files.
- Check platform, required and optional components, exact versions, duplicate and unknown component names, and SHA-256 checksum text format.
- Produce a deterministic report locally and from Lambda.
- Run unit tests and build/deploy the Lambda with AWS SAM through GitHub Actions.

### Out of scope

- Downloading, locating, or hashing artifacts; dependency resolution; semantic version ranges; persistence; web UI; Jira; public HTTP endpoints; product/system/performance/acceptance testing; and release sign-off.
- Runtime network access, secrets, and persistent storage.

### Technical constraints

- Python 3.14; Python standard library for JSON and core behavior; `unittest` or the training repository's established test runner.
- AWS Lambda packaged and deployed with AWS SAM.
- The Lambda accepts a manifest object directly and uses only the policy packaged with the application.
- AWS access is restricted to authorized IAM principals. GitHub deployment uses OIDC and a pre-provisioned least-privilege role; no long-lived AWS keys are stored in GitHub.

## 3. Architecture

Use a small layered design. The validation core is pure: it accepts parsed manifest and policy data and returns a report without file, network, environment, or AWS access. The CLI and Lambda handler are adapters responsible for transport and operational errors.

```mermaid
flowchart LR
    ManifestFile[Manifest JSON file] --> CLI[CLI adapter]
    PolicyFile[Policy JSON file] --> CLI
    CLI --> JsonReader[JSON and I/O boundary]
    JsonReader --> Core[Pure validation core]
    PackagedPolicy[Packaged policy JSON] --> Handler[Lambda adapter]
    LambdaEvent[Manifest event] --> Handler
    Handler --> Core
    Core --> Report[Deterministic report]
    Report --> CLIResult[JSON report file and exit status]
    Report --> LambdaResult[Lambda response]
```

### Component responsibilities

| Component | Responsibility | Must not do |
| --- | --- | --- |
| Policy loader/validator | Read policy at the adapter boundary; validate the policy contract; provide validated policy data to the core. | Accept a caller-supplied policy in Lambda. |
| Validation core | Validate a parsed manifest, compare it with policy, collect/sort issues, and return the report object. | Perform I/O, log inputs, access AWS, or read environment variables. |
| CLI adapter | Parse arguments, read manifest and selected policy, call the core, serialize report, print a short summary, and map outcomes to exit codes. | Duplicate readiness rules. |
| Lambda adapter | Load the packaged policy, pass the event manifest to the core, and return the same report object. | Add a request/response wrapper or convert operational failures into `READY`. |
| SAM template | Define the Lambda, execution role, and CloudWatch log group with seven-day retention. | Create a public endpoint or public storage bucket. |
| GitHub Actions | Run tests/build for pull requests and pushes to `main`; deploy and smoke-test only from `main` using OIDC. | Use long-lived AWS credentials or deploy after failed checks. |

### Proposed package layout

```text
integrator_gate/
    __init__.py
    core.py             # Pure policy/manifest validation and report construction
    cli.py              # Local command adapter
    lambda_handler.py   # AWS Lambda adapter
    policy.py           # Policy loading/validation helpers, if separation is useful
config/
    policy.json
samples/
    ready.json
    blocked/*.json
tests/
    test_core.py
    test_cli.py
    test_lambda_handler.py
template.yaml
.github/workflows/
    ci-and-deploy.yml
README.md
```

This is a proposed layout, matching the requirements. Keep helpers in `core.py` unless a separate module materially improves clarity.

## 4. Data Contracts

All input files and event payloads are UTF-8 JSON. Component names, platform names, and versions are case-sensitive and compared exactly as supplied. Unknown manifest and policy fields are ignored unless they conflict with a required field.

### Policy

```json
{
  "targetPlatform": "linux-x64",
  "required": {
    "core": "2.3.0",
    "ui": "2.3.0"
  },
  "optional": {
    "diagnostics": "1.1.0"
  }
}
```

`targetPlatform` is a nonempty string. `required` and `optional` are maps of nonempty component names to nonempty version strings. A component may not appear in both maps. The optional map may be empty. An invalid policy is a configuration/operational failure; it must never produce a `READY` report.

### Manifest

```json
{
  "releaseId": "REL-2026-001",
  "targetPlatform": "linux-x64",
  "components": [
    {
      "name": "core",
      "version": "2.3.0",
      "buildId": "core-847",
      "sha256": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    }
  ]
}
```

`releaseId`, `targetPlatform`, and each component's `name`, `version`, and `buildId` must be nonempty strings after checking for surrounding whitespace. Preserve the original value for exact comparisons; do not normalize it. `components` must be an array of objects. `sha256` is checked as text for exactly 64 hexadecimal characters, either case. This check does not hash or locate an artifact.

### Report

```json
{
  "releaseId": "REL-2026-001",
  "status": "BLOCKED",
  "issues": [
    {
      "code": "MISSING_REQUIRED",
      "component": "ui",
      "message": "Required component is missing."
    }
  ]
}
```

The report contains only `releaseId`, `status`, and `issues`. Each issue contains string fields `code`, `component`, and `message`. Use an empty component string for manifest-level issues. Sort issues by `code`, then `component`. Do not include timestamps, environment values, secrets, or full manifest contents in the report or logs.

## 5. Validation and Decision Flow

1. The CLI reads UTF-8 JSON files and parses them. Lambda receives an already-decoded event object from the runtime; it does not parse a JSON text file.
2. The adapter validates the policy. Invalid policy stops processing as an operational/configuration failure.
3. The core validates manifest structure and required field values. If structure is invalid, return one `INVALID_INPUT` issue describing the invalid field and do not compare the manifest with the policy.
4. For a structurally valid manifest, evaluate all applicable checks rather than stopping at the first issue:
   - Platform equality (`PLATFORM_MISMATCH`).
   - Presence of every required component (`MISSING_REQUIRED`).
   - Duplicate names (`DUPLICATE_COMPONENT`).
   - Unknown component names (`UNKNOWN_COMPONENT`).
   - Exact approved version (`VERSION_MISMATCH`).
   - Checksum text format (`INVALID_CHECKSUM`).
5. A missing optional component is allowed. A present optional component is checked for duplicate, version, and checksum errors like any other approved component.
6. Sort collected issues by code and component. Return `READY` only when the issue list is empty; otherwise return `BLOCKED`.
7. Echo a valid nonempty `releaseId`; otherwise set report `releaseId` to JSON `null`.

For duplicate names, evaluate each occurrence consistently and report the duplicate condition; required presence is satisfied when that name occurs, while duplicate and other applicable per-component checks remain reportable. Tests should lock down this interpretation.

### Issue codes

| Code | Meaning |
| --- | --- |
| `INVALID_INPUT` | Manifest structure or required field value is invalid. |
| `PLATFORM_MISMATCH` | Manifest platform differs from the policy platform. |
| `MISSING_REQUIRED` | A required component is absent. |
| `DUPLICATE_COMPONENT` | A component name occurs more than once. |
| `UNKNOWN_COMPONENT` | A component name is not in either policy map. |
| `VERSION_MISMATCH` | An approved component's version differs from its exact policy version. |
| `INVALID_CHECKSUM` | Checksum is not exactly 64 hexadecimal characters. |

## 6. Interfaces and Error Handling

### Core interface

The core should expose a function conceptually equivalent to:

```python
validate_manifest(manifest: object, policy: object) -> dict
```

The function has no side effects. It returns the same report contract for equivalent parsed inputs. Parsing and policy/configuration failures remain adapter-level errors; manifest validation failures are represented in the report according to the contract.

### CLI

Command:

```text
python -m integrator_gate validate --manifest samples/ready.json --policy config/policy.json --out reports/ready.json
```

- Create the output parent directory if needed.
- Write JSON with a trailing newline.
- Print a short status summary to stdout; print operational errors to stderr.
- Exit `0` for `READY`, `1` for `BLOCKED`, and `2` for unreadable/malformed JSON, invalid policy, or output I/O failure.
- A structurally invalid but parseable manifest returns `BLOCKED` with `INVALID_INPUT` and exit `1`.

### Lambda

- Input event is the manifest object itself; the function response is the report object itself.
- Load policy only from the deployed package. The caller cannot provide or override it.
- Return `READY` or `BLOCKED` only for successfully evaluated manifests.
- Invalid policy or unexpected operational failure fails the invocation. Do not catch such failures and return a success-shaped `READY` response.
- The function is invoked directly by authorized IAM principals; do not configure API Gateway or a function URL.

### Error separation

| Failure | CLI behavior | Lambda behavior |
| --- | --- | --- |
| Parseable manifest violates contract | Write `BLOCKED` report with `INVALID_INPUT`; exit `1`. | Return `BLOCKED` report with `INVALID_INPUT`. |
| Manifest file cannot be read or its JSON text cannot be parsed | Print operational error to stderr; exit `2`. | Not applicable at the handler boundary; the Lambda runtime supplies a decoded event. |
| Lambda event is decoded JSON but violates the manifest structure | Not applicable. | Return `BLOCKED` with one `INVALID_INPUT` issue through the shared core. |
| Policy is invalid or unreadable | Print operational error to stderr; exit `2`. | Invocation fails; never report `READY`. |
| Output file cannot be written | Print operational error to stderr; exit `2`. | Not applicable; return report directly. |

## 7. Security and Operations

- Keep the Lambda private; authorize invocation through IAM only.
- Use a dedicated training AWS account or controlled sandbox. The AWS region is selected through a workflow variable.
- Use GitHub Actions OIDC with a pre-provisioned least-privilege role scoped to the training repository and `main` branch. Restrict permissions to the training stack and required SAM artifacts.
- Do not store long-lived AWS keys, log full manifests, expose secrets/environment variables in issue messages, or make artifact downloads/network calls.
- Configure a CloudWatch log group with seven-day retention. Log concise operational status and errors without sensitive payload data.
- Document `sam build`, `sam deploy`, Lambda invocation, and `sam delete`. Delete the training stack when it is no longer needed and communicate AWS charges and deployment prerequisites.

## 8. CI/CD and Deployment Design

1. Pull requests and pushes to `main` run the unit test suite and `sam build`.
2. Deployment runs only from `main` and only after required checks pass.
3. The deployment job assumes the pre-provisioned AWS role using GitHub OIDC; long-lived keys are not used.
4. Deploy the SAM stack containing the Lambda and seven-day-retention log group.
5. Invoke Lambda with the ready fixture and assert `status == READY`.
6. Invoke it with a fixture missing a required component and assert `status == BLOCKED`.
7. Provide stack teardown through `sam delete` and document it in the README.

## 9. Test Design

Use independent, deterministic unit tests. Test the pure core separately from the adapters; mock file access or AWS context only at adapter boundaries. Assert report shape, exact issue codes, status, issue sort order, CLI exit codes, and output-file behavior rather than relying only on console text.

Required fixtures/cases from the source requirements:

| Case | Expected result |
| --- | --- |
| Valid ready manifest | `READY`, empty issues. |
| Missing required `ui` | `BLOCKED`, `MISSING_REQUIRED`. |
| Wrong `core` version | `BLOCKED`, `VERSION_MISMATCH`. |
| Duplicate `core` | `BLOCKED`, `DUPLICATE_COMPONENT`. |
| Unknown `debug` | `BLOCKED`, `UNKNOWN_COMPONENT`. |
| Wrong platform | `BLOCKED`, `PLATFORM_MISMATCH`. |
| Malformed checksum | `BLOCKED`, `INVALID_CHECKSUM`. |
| Optional `diagnostics` absent | Remains eligible for `READY`. |
| Optional `diagnostics` with wrong version | `BLOCKED`, `VERSION_MISMATCH`. |
| Missing/invalid `releaseId` | Validate as `INVALID_INPUT` per required-field rules; report `releaseId` is `null`. |
| Malformed manifest JSON file | CLI exit `2`; malformed JSON text cannot be passed to the handler as a decoded event. |
| Invalid policy | CLI exit `2`; Lambda invocation fails. |
| Combined independent failures | All applicable issues collected and sorted by code, then component. |

Also test required fields and wrong types, empty strings/collections, checksum length and character boundaries, exact case-sensitive comparisons, policy overlap, optional-only behavior, repeated deterministic calls, file read/write failures, CLI argument errors, and Lambda use of the packaged policy. Add tests for behavior only where supported by the requirements; record unresolved behavior instead of fabricating expected outcomes.

## 10. Requirement Traceability

| Requirement | Design coverage |
| --- | --- |
| FR-01: Manifest and policy contract | Sections 4, 5, 6, and 9. |
| FR-02: Platform and required components | Sections 5 and 9. |
| FR-03: Duplicates, unknowns, exact versions, checksum format | Sections 5 and 9. |
| FR-04: Deterministic report | Sections 4, 5, and 9. |
| FR-05: Local integration checks | Section 6. |
| FR-06: Shared logic in AWS Lambda | Sections 3 and 6. |
| FR-07: CI and deployment | Sections 7 and 8. |

## 11. Decisions and Open Questions

- **Selected for this exercise:** Python 3.14, standard-library JSON, `unittest` or the existing training runner, pure validation core, thin CLI/Lambda adapters, AWS Lambda with SAM, GitHub Actions OIDC deployment.
- **Not selected for the production telemetry application:** language, framework, libraries, and architecture. Do not infer these from this training exercise.
- **Clarify `releaseId`:** The input rules require a nonempty string, the minimum fixtures include a missing `releaseId`, and report rules say to use `null` when it is not a nonempty string. This design treats a missing/invalid value as `INVALID_INPUT` and emits `null`; confirm this interpretation with the requirements owner.
- **Clarify component duplicate evaluation:** This design reports duplicate names while still collecting independently applicable checks. Confirm whether repeated instances should each be checked or whether only a canonical occurrence should be checked.
- **Clarify malformed Lambda events:** The requirements specify that invalid policy and unexpected failures fail invocation but do not fully define handling for non-object or otherwise unparseable Lambda events. Adapter tests and error behavior should be confirmed before implementation.
- **Confirm test runner:** Use `unittest` unless the supplied training repository already has an established runner.