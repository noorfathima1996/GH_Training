# GitHub Copilot Training: Integration Drop Readiness Gate

**Audience:** Software integrators with basic Python, Git, and command-line experience  
**Duration:** 16 hours total (5 hours concepts, 11 hours hands-on)  
**Deliverable:** A small Python integration gate, automated checks, and a deployment to AWS Lambda  
**Scope:** Integration readiness checks, not product testing or a full release-management system

## 1. Business Context

Before accepting a software drop, an integration team needs to know whether the supplied component list matches an approved integration baseline. Checking names and versions by hand is slow and makes it easy to miss a component or accept an unapproved one.

Build a **readiness gate** that compares a drop manifest with an approved policy. It produces a deterministic JSON report stating `READY` or `BLOCKED` and explains every blocking issue. The same validation logic must run locally and in AWS Lambda. A `READY` report means only that the manifest matches the policy; it does **not** mean the binaries work or that QA has approved the release.

### Users and workflow

1. An integrator maintains a version-controlled policy for one target platform.
2. A drop owner supplies a JSON manifest describing a candidate software drop.
3. The integrator runs the local command, inspects the report, and fixes the manifest or requests an approved policy change.
4. CI checks changes to the gate and policy. After merge, an authorized integrator invokes the deployed Lambda to validate a manifest in AWS.

## 2. MVP Boundaries

**In scope:** Parse a manifest; validate its shape; compare platform, required/optional components, exact versions, and checksum *format* against a checked-in policy; write a JSON report; run the same logic in Lambda; automate unit tests and deployment.

**Out of scope:** Downloading or hashing binaries, checking that an artifact exists, semantic version ranges, dependency resolution, database storage, a web UI, user authentication beyond AWS IAM, Jira integration, performance testing, system testing, acceptance testing of the product, test-case management, and release sign-off. A syntactically valid checksum is **not** proof that an artifact matches it.

The training covers developer/integrator tests of this tool. It does not require a separate testing-team workflow, test environment, product test automation suite, defect triage process, or QA approval stage.

## 3. Inputs and Output Contract

All files and payloads are UTF-8 JSON. Component names and versions are case-sensitive. The policy is owned by the integration team and packaged with the deployed application; callers cannot override it in AWS.

**Approved policy example** (`config/policy.json`):

```json
{
  "targetPlatform": "linux-x64",
  "required": {
    "core": "2.3.0",
    "ui": "2.3.0"
  },
  "optional": {
    "diagnostics": "1.1.0"
  }
}
```

**Candidate drop example** (`samples/ready.json`):

```json
{
  "releaseId": "REL-2026-001",
  "targetPlatform": "linux-x64",
  "components": [
    {
      "name": "core",
      "version": "2.3.0",
      "buildId": "core-847",
      "sha256": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    },
    {
      "name": "ui",
      "version": "2.3.0",
      "buildId": "ui-502",
      "sha256": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"
    }
  ]
}
```

**Report example** (`reports/ready.json`):

```json
{
  "releaseId": "REL-2026-001",
  "status": "READY",
  "issues": []
}
```

### Input rules

- `releaseId`, `targetPlatform`, each component `name`, `version`, and `buildId` must be nonempty strings after trimming surrounding whitespace. Compare names, platforms, and versions exactly as supplied; do not silently normalize their values.
- `components` must be a JSON array; every entry must be an object with all four specified fields. `sha256` must be exactly 64 hexadecimal characters (upper- or lowercase). It is validated as text only.
- The policy must specify a nonempty `targetPlatform` and `required` and `optional` maps of unique, nonempty component names to nonempty version strings. A name may not appear in both maps. An empty `optional` map is allowed.
- Unknown fields are ignored for this MVP; missing fields or fields with the wrong type are invalid. Policy errors are configuration failures and must not produce a `READY` report.

### Decision and report rules

| Code | Blocking condition |
| --- | --- |
| `INVALID_INPUT` | Manifest structure or required field value is invalid |
| `PLATFORM_MISMATCH` | Manifest platform differs from the policy platform |
| `MISSING_REQUIRED` | A required policy component is absent |
| `DUPLICATE_COMPONENT` | A component name appears more than once in the manifest |
| `UNKNOWN_COMPONENT` | A component is not listed in either policy map |
| `VERSION_MISMATCH` | A present approved component has a version different from its exact policy version |
| `INVALID_CHECKSUM` | A component checksum is not 64 hexadecimal characters |

- A missing optional component is allowed. A present optional component must satisfy all applicable checks.
- Return `READY` only if there are no issues; otherwise return `BLOCKED`. Collect all applicable issues for a structurally valid manifest instead of stopping at the first mismatch.
- Each issue is an object with string fields `code`, `component`, and `message`. Use an empty `component` for manifest-level issues. Sort issues by `code`, then `component` so repeated runs with the same inputs produce the same report.
- Echo `releaseId` in the report when it is a nonempty string; otherwise use `null`. Invalid structure returns one `INVALID_INPUT` issue describing the invalid field, and does not attempt further comparison. Messages must not expose secrets or environment variables.
- Local command: `python -m integrator_gate validate --manifest samples/ready.json --policy config/policy.json --out reports/ready.json`. Create the report's parent directory if necessary and write the JSON report with a trailing newline. Exit `0` for `READY`, `1` for `BLOCKED`, and `2` for unreadable/malformed JSON, invalid policy, or output I/O failure. Print a short status summary to stdout; print operational errors to stderr.
- Lambda invocation payload is the manifest object itself. Its response is the same report object as the local command, with no command-line wrapper. An invalid policy or unexpected operational failure must fail the invocation rather than return a `READY` response.

## 4. Functional Requirements and Acceptance Criteria

| ID | Requirement | Acceptance evidence |
| --- | --- | --- |
| FR-01 | Validate the manifest and policy input contract. | Invalid type/missing field gives `INVALID_INPUT`; an invalid policy fails locally with exit `2` and fails Lambda invocation. |
| FR-02 | Check platform and every required component against the approved policy. | Wrong platform and missing `ui` each block the drop with the appropriate code. |
| FR-03 | Check duplicates, unknown components, exact versions, and checksum format. | Each condition has a focused unit test; a supplied optional component with a wrong version blocks. |
| FR-04 | Produce a deterministic, machine-readable report. | A valid example returns the specified `READY` report; repeated validations yield identical JSON values and sorted issues. |
| FR-05 | Support local integration checks. | An integrator can run the documented command; the expected report file and exit code are produced. |
| FR-06 | Reuse the validation logic in AWS. | An authorized `aws lambda invoke` with the ready manifest returns `READY`; a blocked manifest returns `BLOCKED`. |
| FR-07 | Automate checks and deployment. | PR checks pass before merge; merge to `main` deploys to a training AWS environment and runs a smoke invocation. |

### Minimum test fixtures

Maintain a ready sample and blocked variants: missing `ui`, wrong `core` version, duplicate `core`, unknown `debug`, wrong platform, malformed checksum, optional `diagnostics` absent, optional `diagnostics` with wrong version, missing `releaseId`, malformed JSON file, and invalid policy. One combined blocked fixture should demonstrate that independent issues are collected and sorted. Assert codes, status, report shape, and CLI exit codes, not just console text.

## 5. Technical and Operational Requirements

- Use Python 3.14, standard-library JSON handling, and `unittest` or the training team's existing test runner. Keep a pure validation function that accepts parsed data and policy; CLI and Lambda are thin adapters around it.
- Use a small repository layout: `integrator_gate/` (core logic, CLI, Lambda handler), `config/`, `samples/`, `tests/`, `template.yaml` (AWS SAM), `.github/workflows/`, and a short `README.md` with local and AWS run commands.
- No external network calls, secrets, artifact downloads, or persistent storage are required at runtime. The Lambda has no public HTTP endpoint and returns the report to the authorized AWS caller.
- Validate policy during application initialization or before each invocation. Do not accept a policy path or policy body from the Lambda request.
- CI must run unit tests and a SAM build on pull requests and pushes to `main`. Deployment happens only on `main` after checks succeed. A smoke invoke must assert the report status; merely invoking Lambda is insufficient.
- Use GitHub Actions OIDC to assume a pre-provisioned, least-privilege AWS deployment role. Do not store long-lived AWS keys in GitHub. Scope the role trust policy to the training repository and `main` branch; restrict deploy permissions to the training stack and required SAM artifact resources.
- Provision a training stack containing the Lambda and a CloudWatch log group with a seven-day retention period. Use a dedicated training AWS account or controlled sandbox and choose the region through a workflow variable. Never log full manifests if they might contain sensitive identifiers.
- The deployed function must be invokable only by authorized IAM principals. Avoid API Gateway, function URLs, and public S3 buckets in the MVP. Document `sam build`, `sam deploy`, Lambda invocation, and `sam delete` for teardown.
- Acceptance for the training environment: local checks pass; GitHub Actions CI passes; the deployed smoke test returns `READY`; a second AWS invocation returns `BLOCKED` for a missing required component; the stack can be deleted after training. AWS account charges and SAM deployment prerequisites must be communicated in advance.

## 6. Training Prerequisites

The trainer supplies an AWS sandbox, a GitHub training repository, a pre-provisioned OIDC deployment role and trust policy, a deployable SAM starter template, and sample manifests/policy. This keeps IAM bootstrapping and account administration out of the 16-hour exercise. Learners need GitHub Copilot access in VS Code, Git, Python 3.14, AWS CLI, AWS SAM CLI, access to the training repository, and IAM permission to invoke the deployed Lambda. Verify access before the workshop; no secrets should be pasted into Copilot prompts.

## 7. Sixteen-Hour Learning Plan

| Stage | Concept | Hands-on | Learner output and Copilot practice |
| --- | ---: | ---: | --- |
| Requirement analysis | 0.75 h | 1.25 h | Turn the business need into rules, acceptance criteria, and non-goals; ask Copilot to find ambiguity in checksum and readiness wording. |
| Design | 0.75 h | 1.25 h | Sketch CLI/core/Lambda boundaries and input/output examples; use Copilot to compare two small designs. |
| Automate/develop | 0.50 h | 2.50 h | Implement policy validation, pure gate logic, CLI, and Lambda handler in short reviewed increments. |
| Test | 0.50 h | 1.50 h | Generate and review unit tests and fixtures for ready, blocked, malformed, and optional cases. |
| Refactor | 0.50 h | 1.00 h | Remove duplicated adapter logic; rerun the same tests to demonstrate unchanged behavior. |
| Review | 0.50 h | 1.00 h | Review a pull request for correctness, scope, secrets, and missing edge cases; fix one finding. |
| CI/CD | 0.75 h | 1.25 h | Add GitHub Actions checks and an OIDC-backed deploy job for `main`; inspect a failed check. |
| Deploy to AWS | 0.75 h | 1.25 h | Deploy with SAM, invoke ready and blocked manifests, inspect logs, and clean up the stack. |
| **Total** | **5.00 h** | **11.00 h** | **16.00 hours** |

### Suggested Copilot prompts

- **Analyze:** "Review these manifest and policy examples against FR-01 to FR-04. List ambiguous rules and missing acceptance cases; do not write code yet."
- **Design:** "Propose the smallest Python module boundaries for shared validation, a CLI, and a Lambda handler. Keep AWS-specific code out of the validator."
- **Develop:** "Implement FR-02 and FR-03 using the supplied contract. Explain any assumption and keep the returned issue order deterministic."
- **Test:** "Write focused tests for missing required, wrong version, duplicate, and missing optional components. Assert report fields and issue codes."
- **Refactor/review:** "Review this diff against the requirements for regressions, unhandled inputs, and secrets. Suggest the smallest fix and rerun relevant tests."
- **CI/CD:** "Draft a GitHub Actions workflow that tests PRs and deploys from main with OIDC using the supplied role; identify permissions that must be pre-provisioned."

Copilot output is a draft. Learners must inspect generated code and commands, run checks, and explain why each acceptance criterion is met. Do not use Copilot to invent AWS account IDs, role ARNs, credentials, or product-specific release rules.

## 8. Completion Checklist

- Requirements and examples are agreed with the integrator playing the product-owner role.
- Core validation, local CLI, and Lambda handler share the same decision rules.
- All minimum fixtures have passing automated tests and the blocked cases have the expected codes.
- A reviewed pull request shows at least one concrete improvement based on review feedback.
- CI checks the branch, `main` deploys using OIDC, and AWS smoke invocations prove both `READY` and `BLOCKED` outcomes.
- The README includes run, deploy, invocation, limitations, and teardown instructions; the training AWS stack is deleted when no longer needed.