"""Contract-first tests for the proposed pure integration readiness gate."""

import copy
import unittest

from integrator_gate.core import validate_manifest


POLICY = {
    "targetPlatform": "linux-x64",
    "required": {"core": "2.3.0", "ui": "2.3.0"},
    "optional": {"diagnostics": "1.1.0"},
}

MANIFEST = {
    "releaseId": "REL-2026-001",
    "targetPlatform": "linux-x64",
    "components": [
        {"name": "core", "version": "2.3.0", "buildId": "core-847", "sha256": "a" * 64},
        {"name": "ui", "version": "2.3.0", "buildId": "ui-502", "sha256": "b" * 64},
    ],
}


class ValidateManifestTests(unittest.TestCase):
    def test_valid_manifests_are_ready(self):
        cases = (
            ("required only", None),
            ("valid optional", {"name": "diagnostics", "version": "1.1.0", "buildId": "diag-1", "sha256": "A" * 64}),
        )
        for name, optional in cases:
            with self.subTest(name=name):
                manifest = copy.deepcopy(MANIFEST)
                if optional is not None:
                    manifest["components"].append(optional)

                self.assertEqual(
                    {"releaseId": "REL-2026-001", "status": "READY", "issues": []},
                    validate_manifest(manifest, copy.deepcopy(POLICY)),
                )

    def test_structurally_valid_mismatches_are_blocked(self):
        cases = (
            ("wrong platform", lambda m: m.update(targetPlatform="windows-x64"), "PLATFORM_MISMATCH", ""),
            ("missing required", lambda m: m["components"].pop(), "MISSING_REQUIRED", "ui"),
            ("duplicate", lambda m: m["components"].append(copy.deepcopy(m["components"][0])), "DUPLICATE_COMPONENT", "core"),
            (
                "unknown",
                lambda m: m["components"].append(
                    {"name": "debug", "version": "1.0", "buildId": "debug-1", "sha256": "c" * 64}
                ),
                "UNKNOWN_COMPONENT",
                "debug",
            ),
            ("required version", lambda m: m["components"][0].update(version="2.3.1"), "VERSION_MISMATCH", "core"),
            ("case-sensitive version", lambda m: m["components"][1].update(version="2.3.0 "), "VERSION_MISMATCH", "ui"),
            (
                "optional version",
                lambda m: m["components"].append(
                    {"name": "diagnostics", "version": "1.1.2", "buildId": "diag-1", "sha256": "c" * 64}
                ),
                "VERSION_MISMATCH",
                "diagnostics",
            ),
            ("short checksum", lambda m: m["components"][0].update(sha256="a" * 63), "INVALID_CHECKSUM", "core"),
            ("nonhex checksum", lambda m: m["components"][0].update(sha256="a" * 63 + "g"), "INVALID_CHECKSUM", "core"),
        )
        for name, change, code, component in cases:
            with self.subTest(name=name):
                manifest = copy.deepcopy(MANIFEST)
                change(manifest)
                report = validate_manifest(manifest, copy.deepcopy(POLICY))

                self.assertEqual("BLOCKED", report["status"])
                self.assertEqual(manifest["releaseId"], report["releaseId"])
                self.assertIn((code, component), {(issue["code"], issue["component"]) for issue in report["issues"]})
                self.assertTrue(all(set(issue) == {"code", "component", "message"} for issue in report["issues"]))

    def test_invalid_structure_stops_before_comparison(self):
        cases = (
            ("nonobject root", []),
            ("missing release id", {key: value for key, value in MANIFEST.items() if key != "releaseId"}),
            ("empty target platform", {**MANIFEST, "targetPlatform": ""}),
            ("components not an array", {**MANIFEST, "components": None, "targetPlatform": "windows-x64"}),
            ("component entry wrong type", {**MANIFEST, "components": ["core"]}),
            ("missing component name", {**MANIFEST, "components": [{"version": "2.3.0", "buildId": "b1", "sha256": "a" * 64}]}),
            ("blank build id", {**MANIFEST, "components": [{"name": "core", "version": "2.3.0", "buildId": "   ", "sha256": "a" * 64}]}),
        )
        for name, candidate in cases:
            with self.subTest(name=name):
                report = validate_manifest(copy.deepcopy(candidate), copy.deepcopy(POLICY))
                self.assertEqual("BLOCKED", report["status"])
                self.assertEqual(["INVALID_INPUT"], [issue["code"] for issue in report["issues"]])
                self.assertEqual(candidate.get("releaseId") if isinstance(candidate, dict) else None, report["releaseId"])

    def test_uppercase_checksum_is_accepted(self):
        manifest = copy.deepcopy(MANIFEST)
        manifest["components"][0]["sha256"] = manifest["components"][0]["sha256"].upper()

        self.assertEqual(
            {"releaseId": "REL-2026-001", "status": "READY", "issues": []},
            validate_manifest(manifest, copy.deepcopy(POLICY)),
        )

    def test_multiple_independent_issues_are_sorted_and_repeatable(self):
        manifest = copy.deepcopy(MANIFEST)
        manifest["targetPlatform"] = "windows-x64"
        manifest["components"][0]["version"] = "2.3.1"
        manifest["components"][1]["sha256"] = "b" * 63
        manifest["components"].append({"name": "debug", "version": "1.0", "buildId": "debug-1", "sha256": "c" * 64})

        first = validate_manifest(manifest, copy.deepcopy(POLICY))
        second = validate_manifest(copy.deepcopy(manifest), copy.deepcopy(POLICY))

        self.assertEqual(first, second)
        self.assertEqual("BLOCKED", first["status"])
        self.assertEqual(
            {"INVALID_CHECKSUM", "PLATFORM_MISMATCH", "UNKNOWN_COMPONENT", "VERSION_MISMATCH"},
            {issue["code"] for issue in first["issues"]},
        )
        self.assertEqual(
            sorted(first["issues"], key=lambda issue: (issue["code"], issue["component"])),
            first["issues"],
        )


if __name__ == "__main__":
    unittest.main()
