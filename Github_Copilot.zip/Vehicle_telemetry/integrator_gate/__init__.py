"""Integration drop readiness gate."""
