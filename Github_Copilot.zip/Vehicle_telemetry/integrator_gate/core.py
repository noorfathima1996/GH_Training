import re


_CHECKSUM = re.compile(r"[0-9a-fA-F]{64}\Z")


def _nonempty_string(value):
    return isinstance(value, str) and bool(value.strip())


def _issue(code, component, message):
    return {"code": code, "component": component, "message": message}


def _validate_policy(policy):
    if not isinstance(policy, dict) or not _nonempty_string(policy.get("targetPlatform")):
        raise ValueError("Invalid policy targetPlatform")
    for section in ("required", "optional"):
        entries = policy.get(section)
        if not isinstance(entries, dict) or any(
            not _nonempty_string(name) or not _nonempty_string(version)
            for name, version in entries.items()
        ):
            raise ValueError(f"Invalid policy {section}")
    if policy["required"].keys() & policy["optional"].keys():
        raise ValueError("Policy component names overlap")


def validate_manifest(manifest: object, policy: object) -> dict:
    _validate_policy(policy)
    release_id = manifest.get("releaseId") if isinstance(manifest, dict) else None
    if not _nonempty_string(release_id):
        release_id = None

    invalid_field = None
    if not isinstance(manifest, dict):
        invalid_field = "manifest"
    elif release_id is None:
        invalid_field = "releaseId"
    elif not _nonempty_string(manifest.get("targetPlatform")):
        invalid_field = "targetPlatform"
    elif not isinstance(manifest.get("components"), list):
        invalid_field = "components"
    else:
        for index, entry in enumerate(manifest["components"]):
            if not isinstance(entry, dict):
                invalid_field = f"components[{index}]"
                break
            for field in ("name", "version", "buildId"):
                if not _nonempty_string(entry.get(field)):
                    invalid_field = f"components[{index}].{field}"
                    break
            if invalid_field is not None:
                break
            if not isinstance(entry.get("sha256"), str):
                invalid_field = f"components[{index}].sha256"
                break

    if invalid_field is not None:
        return {
            "releaseId": release_id,
            "status": "BLOCKED",
            "issues": [_issue("INVALID_INPUT", "", f"Invalid {invalid_field}.")],
        }

    issues = []
    if manifest["targetPlatform"] != policy["targetPlatform"]:
        issues.append(_issue("PLATFORM_MISMATCH", "", "Target platform does not match policy."))

    components = manifest["components"]
    names = {entry["name"] for entry in components}
    for name in policy["required"]:
        if name not in names:
            issues.append(_issue("MISSING_REQUIRED", name, "Required component is missing."))

    seen = set()
    for entry in components:
        name = entry["name"]
        if name in seen:
            issues.append(_issue("DUPLICATE_COMPONENT", name, "Component appears more than once."))
        seen.add(name)

        expected_version = policy["required"].get(name, policy["optional"].get(name))
        if expected_version is None:
            issues.append(_issue("UNKNOWN_COMPONENT", name, "Component is not approved."))
        elif entry["version"] != expected_version:
            issues.append(_issue("VERSION_MISMATCH", name, "Component version does not match policy."))

        if not _CHECKSUM.fullmatch(entry["sha256"]):
            issues.append(_issue("INVALID_CHECKSUM", name, "Checksum must be 64 hexadecimal characters."))

    issues.sort(key=lambda issue: (issue["code"], issue["component"]))
    return {"releaseId": release_id, "status": "BLOCKED" if issues else "READY", "issues": issues}
